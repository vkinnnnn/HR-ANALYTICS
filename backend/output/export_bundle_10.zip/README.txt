Workforce Analytics Export — 2026-03-27
Total employees: 2466
Active: 1110
Departed: 1356
History records: 11803
